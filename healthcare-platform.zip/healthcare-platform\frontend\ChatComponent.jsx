/**
 * React Component Example for Healthcare Platform
 * Shows how to integrate the AI assistant in a React app
 */

import React, { useState, useEffect, useRef } from 'react';
import HealthcareAIClient from './client.js';

/**
 * Healthcare AI Chat Component
 * Main UI component for the healthcare assistant
 */
export function HealthcareChatComponent({ userId, userRole, token, patientId }) {
  const [messages, setMessages] = useState([]);
  const [inputValue, setInputValue] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const [isEmergency, setIsEmergency] = useState(false);
  const [userData, setUserData] = useState(null);
  const messagesEndRef = useRef(null);
  const clientRef = useRef(null);

  // Initialize client
  useEffect(() => {
    clientRef.current = new HealthcareAIClient({
      baseURL: process.env.REACT_APP_API_URL || 'http://localhost:3000/api/v1',
      userId,
      userRole,
      token
    });

    // Start conversation
    initializeConversation();
    fetchUserData();
  }, [userId, userRole, token]);

  // Scroll to bottom of messages
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  const initializeConversation = async () => {
    const result = await clientRef.current.startConversation(patientId);
    if (!result.success) {
      setError('Failed to start conversation');
    }
  };

  const fetchUserData = async () => {
    const result = await clientRef.current.getUserRole();
    if (result.success) {
      setUserData(result);
    }
  };

  const handleSendMessage = async () => {
    if (!inputValue.trim()) return;

    const userMessage = inputValue;
    setInputValue('');
    setError(null);

    // Add user message to UI
    setMessages(prev => [...prev, {
      role: 'user',
      content: userMessage,
      timestamp: new Date()
    }]);

    setLoading(true);

    try {
      const response = await clientRef.current.sendMessage(userMessage, patientId);

      if (response.success) {
        // Add AI response
        setMessages(prev => [...prev, {
          role: 'assistant',
          content: response.response,
          timestamp: new Date(response.metadata?.timestamp),
          isEmergency: response.isEmergency
        }]);

        // Handle emergency
        if (response.isEmergency) {
          setIsEmergency(true);
          handleEmergencyState();
        }
      } else {
        setError(response.error || 'Failed to get response');
      }
    } catch (err) {
      setError('Error communicating with server');
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const handleEmergencyState = () => {
    // Highlight emergency message, perhaps play sound
    // In production: trigger notifications, highlight UI, etc.
    console.warn('Emergency situation detected');
  };

  const handleKeyPress = (e) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSendMessage();
    }
  };

  return (
    <div className="healthcare-chat-container">
      {/* Header */}
      <div className="chat-header">
        <h2>Healthcare AI Assistant</h2>
        <div className="user-info">
          <span>{userRole.toUpperCase()}</span>
          {userData && <span>Permissions: {userData.permissions?.length}</span>}
        </div>
      </div>

      {/* Emergency Banner */}
      {isEmergency && (
        <div className="emergency-banner">
          🚨 EMERGENCY DETECTED - Professional help is being notified. Call 911 if needed.
        </div>
      )}

      {/* Error Banner */}
      {error && (
        <div className="error-banner">
          ⚠️ {error}
        </div>
      )}

      {/* Messages Area */}
      <div className="messages-container">
        {messages.length === 0 ? (
          <div className="welcome-message">
            <h3>Welcome to Healthcare AI Assistant</h3>
            <p>Ask me questions about your health, medications, or appointments.</p>
            <p className="disclaimer">
              ⚠️ This is not a medical diagnosis tool. Always consult healthcare professionals.
            </p>
          </div>
        ) : (
          messages.map((msg, idx) => (
            <div
              key={idx}
              className={`message ${msg.role} ${msg.isEmergency ? 'emergency' : ''}`}
            >
              <div className="message-header">
                {msg.role === 'user' ? '👤 You' : '🤖 Assistant'}
                <span className="timestamp">
                  {msg.timestamp?.toLocaleTimeString()}
                </span>
              </div>
              <div className="message-content">
                {msg.content}
              </div>
              {msg.isEmergency && (
                <div className="emergency-indicator">
                  🚨 Emergency Response
                </div>
              )}
            </div>
          ))
        )}
        {loading && (
          <div className="message assistant loading">
            <div className="typing-indicator">
              <span></span><span></span><span></span>
            </div>
          </div>
        )}
        <div ref={messagesEndRef} />
      </div>

      {/* Input Area */}
      <div className="input-container">
        <textarea
          value={inputValue}
          onChange={(e) => setInputValue(e.target.value)}
          onKeyPress={handleKeyPress}
          placeholder="Type your message here... (Shift+Enter for new line)"
          disabled={loading}
          rows="3"
        />
        <button
          onClick={handleSendMessage}
          disabled={loading || !inputValue.trim()}
          className="send-button"
        >
          {loading ? 'Sending...' : 'Send'}
        </button>
      </div>

      {/* Footer Info */}
      <div className="chat-footer">
        <small>
          Role: {userRole} | 
          Messages: {messages.length} |
          Last Updated: {new Date().toLocaleTimeString()}
        </small>
      </div>
    </div>
  );
}

/**
 * Example CSS Styles
 */
export const chatStyles = `
.healthcare-chat-container {
  display: flex;
  flex-direction: column;
  height: 100vh;
  max-width: 800px;
  margin: 0 auto;
  border: 1px solid #e0e0e0;
  border-radius: 8px;
  overflow: hidden;
  box-shadow: 0 2px 8px rgba(0,0,0,0.1);
}

.chat-header {
  background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
  color: white;
  padding: 16px;
  display: flex;
  justify-content: space-between;
  align-items: center;
}

.user-info {
  display: flex;
  gap: 12px;
  font-size: 12px;
}

.emergency-banner,
.error-banner {
  padding: 12px 16px;
  text-align: center;
  font-weight: bold;
}

.emergency-banner {
  background-color: #ffebee;
  color: #c62828;
  border-bottom: 2px solid #c62828;
}

.error-banner {
  background-color: #fff3e0;
  color: #e65100;
}

.messages-container {
  flex: 1;
  overflow-y: auto;
  padding: 16px;
  background-color: #f5f5f5;
  display: flex;
  flex-direction: column;
  gap: 12px;
}

.welcome-message {
  text-align: center;
  color: #666;
  padding: 32px 16px;
}

.disclaimer {
  font-size: 12px;
  color: #999;
  margin-top: 12px;
}

.message {
  max-width: 80%;
  padding: 12px 16px;
  border-radius: 8px;
  animation: fadeIn 0.3s ease;
}

.message.user {
  align-self: flex-end;
  background-color: #667eea;
  color: white;
}

.message.assistant {
  align-self: flex-start;
  background-color: white;
  color: #333;
  border: 1px solid #e0e0e0;
}

.message.emergency {
  border: 2px solid #c62828;
  background-color: #ffebee;
}

.message-header {
  font-size: 12px;
  font-weight: bold;
  margin-bottom: 4px;
  display: flex;
  justify-content: space-between;
}

.timestamp {
  font-size: 10px;
  opacity: 0.7;
  margin-left: 8px;
}

.message-content {
  line-height: 1.4;
}

.emergency-indicator {
  margin-top: 8px;
  padding: 8px;
  background-color: #ffcdd2;
  border-radius: 4px;
  font-size: 12px;
  font-weight: bold;
}

.typing-indicator {
  display: flex;
  gap: 4px;
}

.typing-indicator span {
  width: 8px;
  height: 8px;
  background-color: #999;
  border-radius: 50%;
  animation: bounce 1.4s infinite;
}

.typing-indicator span:nth-child(2) {
  animation-delay: 0.2s;
}

.typing-indicator span:nth-child(3) {
  animation-delay: 0.4s;
}

.input-container {
  display: flex;
  gap: 8px;
  padding: 16px;
  background-color: white;
  border-top: 1px solid #e0e0e0;
}

textarea {
  flex: 1;
  padding: 8px 12px;
  border: 1px solid #e0e0e0;
  border-radius: 4px;
  font-family: inherit;
  font-size: 14px;
  resize: none;
}

.send-button {
  padding: 8px 24px;
  background-color: #667eea;
  color: white;
  border: none;
  border-radius: 4px;
  cursor: pointer;
  font-weight: bold;
  transition: background-color 0.3s;
}

.send-button:hover:not(:disabled) {
  background-color: #5568d3;
}

.send-button:disabled {
  opacity: 0.5;
  cursor: not-allowed;
}

.chat-footer {
  padding: 8px 16px;
  background-color: #f0f0f0;
  border-top: 1px solid #e0e0e0;
  text-align: center;
  color: #999;
}

@keyframes fadeIn {
  from {
    opacity: 0;
    transform: translateY(10px);
  }
  to {
    opacity: 1;
    transform: translateY(0);
  }
}

@keyframes bounce {
  0%, 80%, 100% {
    transform: scale(0.8);
    opacity: 0.5;
  }
  40% {
    transform: scale(1);
    opacity: 1;
  }
}
`;

export default HealthcareChatComponent;
