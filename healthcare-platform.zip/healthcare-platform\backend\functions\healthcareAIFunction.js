/**
 * Main Healthcare AI Function
 * Orchestrates role-based LLM interactions
 * This is the primary Antigravity function
 */

import llmService from './llmIntegration.js';
import { buildLLMPayload, detectEmergency } from '../prompts/promptManager.js';

/**
 * Main function: Process user query with role-based logic
 * @param {object} request - HTTP request from frontend
 * @returns {Promise<object>} AI response with role-based context
 */
export async function processHealthcareQuery(request) {
  try {
    const {
      userId,
      userRole,
      patientId,
      message,
      conversationHistory = []
    } = request.body;

    // Validate request
    if (!userId || !userRole || !message) {
      return {
        success: false,
        error: 'Missing required fields: userId, userRole, message',
        status: 400
      };
    }

    // Validate role
    const validRoles = ['patient', 'doctor', 'caretaker', 'admin'];
    if (!validRoles.includes(userRole)) {
      return {
        success: false,
        error: `Invalid role: ${userRole}`,
        status: 400
      };
    }

    // Check authorization for patient access
    if (patientId && !isAuthorizedToAccessPatient(userId, userRole, patientId)) {
      return {
        success: false,
        error: 'Unauthorized to access this patient\'s data',
        status: 403
      };
    }

    // Fetch patient data if authorized
    let patientData = null;
    if (patientId) {
      patientData = await fetchPatientHealthData(patientId);
    }

    // Check for emergency
    const isEmergency = detectEmergency(message);

    // Build LLM payload with all context
    const llmPayload = buildLLMPayload({
      userId,
      userRole,
      patientId,
      userMessage: message,
      patientData,
      conversationHistory
    });

    // Get LLM client (initialized in Antigravity context)
    const llmClient = getActiveLLMClient();

    // Send to LLM
    const aiResponse = await llmClient.sendMessage(
      llmPayload.systemPrompt,
      message
    );

    // Handle emergency response
    if (isEmergency) {
      await triggerEmergencyProtocol({
        userId,
        userRole,
        patientId,
        message,
        aiResponse
      });
    }

    // Save to conversation log
    await saveConversationLog({
      userId,
      userRole,
      patientId,
      userMessage: message,
      aiResponse: aiResponse.content,
      isEmergency,
      promptUsed: llmPayload.systemPrompt
    });

    return {
      success: true,
      response: aiResponse.content,
      isEmergency,
      metadata: {
        userRole,
        timestamp: new Date().toISOString(),
        model: aiResponse.model,
        usage: aiResponse.usage
      }
    };

  } catch (error) {
    console.error('Error processing healthcare query:', error);
    return {
      success: false,
      error: error.message,
      status: 500
    };
  }
}

/**
 * Check if user is authorized to access patient data
 * @param {string} userId - User ID
 * @param {string} userRole - User role
 * @param {string} patientId - Patient ID
 * @returns {boolean} True if authorized
 */
function isAuthorizedToAccessPatient(userId, userRole, patientId) {
  // Patients can only access their own data
  if (userRole === 'patient') {
    return userId === patientId;
  }

  // Doctors/Caretakers/Admins can access assigned patients
  // In production, check database for assignments
  if (['doctor', 'caretaker', 'admin'].includes(userRole)) {
    // TODO: Check database for patient assignment
    return true;
  }

  return false;
}

/**
 * Fetch patient health data from database
 * @param {string} patientId - Patient ID
 * @returns {Promise<object>} Patient health data
 */
async function fetchPatientHealthData(patientId) {
  try {
    // Query database for latest patient data
    // This would use Antigravity's database query
    const query = `
      SELECT * FROM PatientHealthData 
      WHERE patient_id = $1 
      ORDER BY timestamp DESC 
      LIMIT 1
    `;

    const result = await executeQuery(query, [patientId]);
    return result[0] || null;

  } catch (error) {
    console.error('Error fetching patient data:', error);
    return null;
  }
}

/**
 * Save conversation to log
 * @param {object} data - Conversation data
 * @returns {Promise<void>}
 */
async function saveConversationLog(data) {
  try {
    const query = `
      INSERT INTO ConversationLog (
        conversation_id, user_id, patient_id, user_role,
        user_message, ai_response, prompt_used, is_emergency,
        created_at
      ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, NOW())
    `;

    const conversationId = generateId();
    const values = [
      conversationId,
      data.userId,
      data.patientId || null,
      data.userRole,
      data.userMessage,
      data.aiResponse,
      data.promptUsed,
      data.isEmergency
    ];

    await executeQuery(query, values);

  } catch (error) {
    console.error('Error saving conversation log:', error);
  }
}

/**
 * Trigger emergency protocol
 * @param {object} data - Emergency data
 * @returns {Promise<void>}
 */
async function triggerEmergencyProtocol(data) {
  try {
    // Create emergency alert
    const alertId = generateId();
    const query = `
      INSERT INTO Alerts (
        alert_id, patient_id, alert_type, severity,
        message, triggered_by, created_at
      ) VALUES ($1, $2, $3, $4, $5, $6, NOW())
    `;

    await executeQuery(query, [
      alertId,
      data.patientId || data.userId,
      'emergency_detected',
      'high',
      `Emergency detected: ${data.message.substring(0, 100)}...`,
      data.userId
    ]);

    // Log emergency for audit
    console.warn('[EMERGENCY ALERT]', {
      patientId: data.patientId,
      userId: data.userId,
      timestamp: new Date().toISOString()
    });

    // Send notifications (implement based on your system)
    // await notifyEmergencyServices(data);

  } catch (error) {
    console.error('Error in emergency protocol:', error);
  }
}

/**
 * Get active LLM client (from Antigravity context)
 * @returns {object} LLM client
 */
function getActiveLLMClient() {
  // In Antigravity, this would be injected from the platform
  // For now, return a mock implementation
  return {
    async sendMessage(systemPrompt, userMessage) {
      return {
        success: true,
        content: 'Mock response',
        model: 'mock'
      };
    }
  };
}

/**
 * Execute database query (Antigravity wrapper)
 * @param {string} query - SQL query
 * @param {array} values - Query parameters
 * @returns {Promise<array>} Query results
 */
async function executeQuery(query, values) {
  // This would use Antigravity's database query method
  // Placeholder for now
  return [];
}

/**
 * Generate unique ID
 * @returns {string} UUID-like ID
 */
function generateId() {
  return `${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
}

export default {
  processHealthcareQuery,
  isAuthorizedToAccessPatient,
  fetchPatientHealthData
};
