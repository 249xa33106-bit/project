/**
 * Prompt Configuration & Management
 * Handles system, role-based, and emergency prompts
 */

import {
  SYSTEM_PROMPT,
  PATIENT_PROMPT,
  DOCTOR_PROMPT,
  CARETAKER_PROMPT,
  ADMIN_PROMPT,
  EMERGENCY_PROMPT
} from './systemPrompts.js';

/**
 * Get role-specific prompt
 * @param {string} role - User role (patient, doctor, caretaker, admin)
 * @returns {string} Role-specific prompt
 */
export function getRolePrompt(role) {
  const prompts = {
    patient: PATIENT_PROMPT,
    doctor: DOCTOR_PROMPT,
    caretaker: CARETAKER_PROMPT,
    admin: ADMIN_PROMPT
  };
  
  return prompts[role] || PATIENT_PROMPT; // Default to patient
}

/**
 * Build complete prompt for LLM request
 * @param {object} params - Request parameters
 * @returns {string} Complete system message for LLM
 */
export function buildLLMPrompt(params) {
  const { role, isEmergency, patientData, userContext } = params;
  
  let prompt = SYSTEM_PROMPT;
  
  // Add role-specific prompt
  prompt += `\n\n--- ROLE-BASED INSTRUCTIONS ---\n${getRolePrompt(role)}`;
  
  // Add emergency prompt if triggered
  if (isEmergency) {
    prompt += `\n\n--- EMERGENCY MODE ---\n${EMERGENCY_PROMPT}`;
  }
  
  // Add patient data context (if available and authorized)
  if (patientData && shouldIncludePatientData(role)) {
    prompt += `\n\n--- PATIENT CONTEXT (Last 24h) ---\n${formatPatientContext(patientData)}`;
  }
  
  // Add user context
  if (userContext) {
    prompt += `\n\n--- USER CONTEXT ---\n${formatUserContext(userContext)}`;
  }
  
  return prompt;
}

/**
 * Determine if patient data should be included based on role
 * @param {string} role - User role
 * @returns {boolean} Whether to include data
 */
function shouldIncludePatientData(role) {
  // Doctor and caretaker can see data; patient sees summary
  return ['doctor', 'caretaker', 'patient'].includes(role);
}

/**
 * Format patient health data for prompt context
 * @param {object} data - Patient health data
 * @returns {string} Formatted data context
 */
function formatPatientContext(data) {
  return `
Vitals: BP ${data.vitals?.bloodPressure || 'N/A'}, HR ${data.vitals?.heartRate || 'N/A'}
Recent Reports: ${data.reports?.slice(-2).map(r => r.type).join(', ') || 'None'}
Current Medications: ${data.medications?.map(m => m.name).join(', ') || 'None'}
Last Updated: ${data.timestamp || 'Unknown'}
`;
}

/**
 * Format user context for prompt
 * @param {object} context - User context info
 * @returns {string} Formatted context
 */
function formatUserContext(context) {
  return `
User: ${context.name} (${context.role})
Accessing: ${context.targetPatient ? `Patient ID: ${context.targetPatient}` : 'Personal data'}
Time: ${new Date().toISOString()}
`;
}

/**
 * Detect emergency keywords in user message
 * @param {string} message - User message
 * @returns {boolean} True if emergency keywords detected
 */
export function detectEmergency(message) {
  const emergencyKeywords = [
    'help',
    'emergency',
    'pain',
    'unconscious',
    'urgent',
    'crisis',
    'dying',
    'severe',
    'critical',
    '911',
    'ambulance',
    'bleeding',
    'chest pain',
    'cannot breathe',
    'loss of consciousness'
  ];
  
  const lowerMessage = message.toLowerCase();
  return emergencyKeywords.some(keyword => lowerMessage.includes(keyword));
}

/**
 * Build final LLM request payload
 * @param {object} params - All request parameters
 * @returns {object} Complete payload for LLM API
 */
export function buildLLMPayload(params) {
  const {
    userId,
    userRole,
    patientId,
    userMessage,
    patientData,
    conversationHistory = []
  } = params;
  
  // Detect emergency
  const isEmergency = detectEmergency(userMessage);
  
  // Build system prompt
  const systemPrompt = buildLLMPrompt({
    role: userRole,
    isEmergency,
    patientData,
    userContext: { name: userId, role: userRole, targetPatient: patientId }
  });
  
  // Build messages array
  const messages = [
    ...conversationHistory,
    { role: 'user', content: userMessage }
  ];
  
  return {
    systemPrompt,
    messages,
    isEmergency,
    metadata: {
      userId,
      userRole,
      patientId,
      timestamp: new Date().toISOString(),
      messageHash: hashMessage(userMessage)
    }
  };
}

/**
 * Simple hash for message tracking
 * @param {string} message - Message to hash
 * @returns {string} Hash
 */
function hashMessage(message) {
  return require('crypto')
    .createHash('sha256')
    .update(message)
    .digest('hex')
    .slice(0, 8);
}

export default {
  getRolePrompt,
  buildLLMPrompt,
  detectEmergency,
  buildLLMPayload,
  shouldIncludePatientData
};
