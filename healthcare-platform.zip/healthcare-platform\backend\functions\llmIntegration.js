/**
 * LLM Integration Module
 * Handles communication with Gemini/OpenAI LLM
 */

import { buildLLMPayload, detectEmergency } from '../prompts/promptManager.js';

/**
 * Initialize LLM client
 * @param {object} config - Configuration from antigravity.config.json
 * @returns {object} LLM client instance
 */
export function initializeLLMClient(config) {
  const { provider, api_key, model } = config.llm;
  
  if (provider === 'gemini') {
    return initializeGemini(api_key, model);
  } else if (provider === 'openai') {
    return initializeOpenAI(api_key, model);
  } else {
    throw new Error(`Unsupported LLM provider: ${provider}`);
  }
}

/**
 * Initialize Gemini client
 * @param {string} apiKey - Gemini API key
 * @param {string} model - Model name
 * @returns {object} Gemini client
 */
function initializeGemini(apiKey, model) {
  // Using Google Generative AI library
  const { GoogleGenerativeAI } = require('@google/generative-ai');
  const genAI = new GoogleGenerativeAI(apiKey);
  
  return {
    provider: 'gemini',
    model: genAI.getGenerativeModel({ model: model || 'gemini-pro' }),
    async sendMessage(systemPrompt, userMessage) {
      try {
        const chat = this.model.startChat({
          history: [],
          generationConfig: {
            temperature: 0.7,
            topK: 40,
            topP: 0.95,
            maxOutputTokens: 500
          }
        });
        
        const fullPrompt = `${systemPrompt}\n\nUser: ${userMessage}`;
        const result = await chat.sendMessage(fullPrompt);
        const response = await result.response;
        
        return {
          success: true,
          content: response.text(),
          model: 'gemini',
          usage: {
            promptTokens: 0,
            completionTokens: 0
          }
        };
      } catch (error) {
        return {
          success: false,
          error: error.message,
          content: 'I encountered an error processing your request. Please try again.'
        };
      }
    }
  };
}

/**
 * Initialize OpenAI client
 * @param {string} apiKey - OpenAI API key
 * @param {string} model - Model name
 * @returns {object} OpenAI client
 */
function initializeOpenAI(apiKey, model) {
  const { OpenAI } = require('openai');
  const client = new OpenAI({ apiKey });
  
  return {
    provider: 'openai',
    client,
    async sendMessage(systemPrompt, userMessage) {
      try {
        const completion = await this.client.chat.completions.create({
          model: model || 'gpt-3.5-turbo',
          messages: [
            { role: 'system', content: systemPrompt },
            { role: 'user', content: userMessage }
          ],
          temperature: 0.7,
          max_tokens: 500,
          timeout: 30000
        });
        
        return {
          success: true,
          content: completion.choices[0].message.content,
          model: 'openai',
          usage: {
            promptTokens: completion.usage.prompt_tokens,
            completionTokens: completion.usage.completion_tokens
          }
        };
      } catch (error) {
        return {
          success: false,
          error: error.message,
          content: 'I encountered an error processing your request. Please try again.'
        };
      }
    }
  };
}

/**
 * Send message to LLM with full context
 * @param {object} client - LLM client instance
 * @param {object} params - Request parameters
 * @returns {Promise<object>} LLM response with metadata
 */
export async function sendToLLM(client, params) {
  // Build complete payload
  const payload = buildLLMPayload(params);
  
  // Log request for audit
  logConversation(payload, 'request');
  
  // Send to LLM
  const response = await client.sendMessage(
    payload.systemPrompt,
    params.userMessage
  );
  
  // Add emergency flag and metadata
  response.isEmergency = payload.isEmergency;
  response.metadata = payload.metadata;
  
  // Log response for audit
  logConversation({ ...payload, response }, 'response');
  
  return response;
}

/**
 * Log conversation for audit trail
 * @param {object} data - Conversation data
 * @param {string} type - Request or response
 */
function logConversation(data, type) {
  // In production, this would save to database
  const timestamp = new Date().toISOString();
  console.log(`[${timestamp}] AUDIT LOG (${type.toUpperCase()}):`, {
    userId: data.metadata?.userId,
    userRole: data.metadata?.userRole,
    isEmergency: data.isEmergency,
    messageHash: data.metadata?.messageHash
  });
}

export default {
  initializeLLMClient,
  sendToLLM,
  detectEmergency
};
