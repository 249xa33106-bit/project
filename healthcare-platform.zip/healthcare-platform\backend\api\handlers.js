/**
 * API Request Handlers
 * Implements the endpoint logic in Antigravity functions
 */

import healthcareAI from '../functions/healthcareAIFunction.js';
import roleLogic from '../functions/roleBasedLogic.js';

/**
 * Handle POST /api/v1/chat
 * Main LLM query handler with role-based logic
 */
export async function handleChatRequest(req, res) {
  try {
    const { userId, userRole, patientId, message, conversationHistory } = req.body;

    // Input validation
    if (!userId || !userRole || !message) {
      return res.status(400).json({
        success: false,
        error: 'Missing required fields'
      });
    }

    // Validate role
    if (!Object.keys(roleLogic.ROLES).includes(userRole)) {
      return res.status(400).json({
        success: false,
        error: 'Invalid role'
      });
    }

    // Check authorization
    if (patientId && !await roleLogic.canAccessPatientData(userId, userRole, patientId, 'vitals')) {
      return res.status(403).json({
        success: false,
        error: 'Unauthorized to access this patient data'
      });
    }

    // Process query
    const result = await healthcareAI.processHealthcareQuery({
      body: {
        userId,
        userRole,
        patientId,
        message,
        conversationHistory
      }
    });

    // Return response
    if (result.success) {
      return res.status(200).json(result);
    } else {
      return res.status(result.status || 500).json(result);
    }

  } catch (error) {
    console.error('Error handling chat request:', error);
    return res.status(500).json({
      success: false,
      error: 'Internal server error'
    });
  }
}

/**
 * Handle GET /api/v1/patients/:patientId/health-data
 * Fetch patient health data with role-based filtering
 */
export async function handleGetPatientData(req, res) {
  try {
    const { patientId } = req.params;
    const { userId, userRole } = req.user; // From auth middleware
    const {
      includeMedications = true,
      includeReports = true,
      includeAlerts = false
    } = req.query;

    // Check authorization
    const authorized = await roleLogic.canAccessPatientData(
      userId,
      userRole,
      patientId,
      'vitals'
    );

    if (!authorized) {
      // Log unauthorized access attempt
      await roleLogic.logDataAccess({
        userId,
        userRole,
        patientId,
        dataType: 'health_data',
        accessGranted: false
      });

      return res.status(403).json({
        success: false,
        error: 'Unauthorized'
      });
    }

    // Fetch patient data
    const rawData = await healthcareAI.fetchPatientHealthData(patientId);

    if (!rawData) {
      return res.status(404).json({
        success: false,
        error: 'Patient data not found'
      });
    }

    // Filter data based on role
    const filteredData = roleLogic.filterDataByRole(userRole, rawData);

    // Apply query filters
    if (!includeMedications) {
      delete filteredData.medications;
    }
    if (!includeReports) {
      delete filteredData.reports;
    }
    if (!includeAlerts) {
      delete filteredData.alerts;
    }

    // Log access
    await roleLogic.logDataAccess({
      userId,
      userRole,
      patientId,
      dataType: 'health_data',
      accessGranted: true
    });

    return res.status(200).json({
      success: true,
      data: filteredData,
      metadata: {
        lastUpdated: rawData.timestamp,
        dataClassification: userRole === 'admin' ? 'full' : 'partial'
      }
    });

  } catch (error) {
    console.error('Error fetching patient data:', error);
    return res.status(500).json({
      success: false,
      error: 'Internal server error'
    });
  }
}

/**
 * Handle POST /api/v1/alerts
 * Create health alert
 */
export async function handleCreateAlert(req, res) {
  try {
    const { patientId, alertType, severity, message } = req.body;
    const { userId, userRole } = req.user;

    // Validate input
    if (!patientId || !alertType || !severity || !message) {
      return res.status(400).json({
        success: false,
        error: 'Missing required fields'
      });
    }

    if (!['low', 'medium', 'high'].includes(severity)) {
      return res.status(400).json({
        success: false,
        error: 'Invalid severity level'
      });
    }

    // Check authorization (admins and doctors can create alerts)
    if (!['doctor', 'admin'].includes(userRole)) {
      return res.status(403).json({
        success: false,
        error: 'Insufficient permissions'
      });
    }

    // Create alert
    const alertId = generateId();
    const query = `
      INSERT INTO Alerts (
        alert_id, patient_id, alert_type, severity,
        message, triggered_by, created_at
      ) VALUES ($1, $2, $3, $4, $5, $6, NOW())
    `;

    await executeQuery(query, [
      alertId,
      patientId,
      alertType,
      severity,
      message,
      userId
    ]);

    return res.status(201).json({
      success: true,
      alertId,
      timestamp: new Date().toISOString()
    });

  } catch (error) {
    console.error('Error creating alert:', error);
    return res.status(500).json({
      success: false,
      error: 'Internal server error'
    });
  }
}

/**
 * Handle GET /api/v1/users/:userId/role
 * Get user role and permissions
 */
export async function handleGetUserRole(req, res) {
  try {
    const { userId } = req.params;
    const { userId: requestingUserId, userRole: requestingRole } = req.user;

    // Users can only check their own role (except admins)
    if (userId !== requestingUserId && requestingRole !== 'admin') {
      return res.status(403).json({
        success: false,
        error: 'Unauthorized'
      });
    }

    // Fetch user role from database
    const query = 'SELECT role FROM Users WHERE user_id = $1 LIMIT 1';
    const result = await executeQuery(query, [userId]);

    if (!result || result.length === 0) {
      return res.status(404).json({
        success: false,
        error: 'User not found'
      });
    }

    const role = result[0].role;
    const roleConfig = roleLogic.ROLES[role];

    return res.status(200).json({
      success: true,
      role,
      permissions: roleConfig.permissions,
      dataAccess: roleConfig.data_access
    });

  } catch (error) {
    console.error('Error fetching user role:', error);
    return res.status(500).json({
      success: false,
      error: 'Internal server error'
    });
  }
}

/**
 * Helper: Generate unique ID
 */
function generateId() {
  return `${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
}

/**
 * Helper: Execute database query
 */
async function executeQuery(query, values) {
  // This would use Antigravity's database query method
  return [];
}

export default {
  handleChatRequest,
  handleGetPatientData,
  handleCreateAlert,
  handleGetUserRole
};
