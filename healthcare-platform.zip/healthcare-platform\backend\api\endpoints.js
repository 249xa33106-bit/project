/**
 * API Endpoints for Healthcare Platform
 * Antigravity REST API Configuration
 */

/**
 * POST /api/v1/chat
 * Main endpoint: Process user query with LLM
 */
export const chatEndpoint = {
  path: '/api/v1/chat',
  method: 'POST',
  auth: 'required',
  description: 'Send message to healthcare AI assistant',
  requestBody: {
    userId: 'string (required)',
    userRole: 'enum: patient|doctor|caretaker|admin (required)',
    patientId: 'string (optional - required for doctor/caretaker accessing patient)',
    message: 'string (required)',
    conversationId: 'string (optional - for conversation continuity)'
  },
  responseBody: {
    success: 'boolean',
    response: 'string (AI response)',
    isEmergency: 'boolean',
    metadata: {
      userRole: 'string',
      timestamp: 'ISO datetime',
      model: 'string',
      usage: {
        promptTokens: 'number',
        completionTokens: 'number'
      }
    }
  },
  examples: {
    patientQuery: {
      request: {
        userId: 'patient_001',
        userRole: 'patient',
        message: 'What should I do about my high blood pressure?'
      },
      response: {
        success: true,
        response: 'High blood pressure requires professional attention. Contact your doctor...',
        isEmergency: false,
        metadata: {
          userRole: 'patient',
          timestamp: '2024-01-20T10:30:00Z'
        }
      }
    },
    emergencyQuery: {
      request: {
        userId: 'patient_002',
        userRole: 'patient',
        message: 'I have severe chest pain and cannot breathe!'
      },
      response: {
        success: true,
        response: '🚨 EMERGENCY: CALL 911 IMMEDIATELY. While waiting: Sit down, try slow breathing...',
        isEmergency: true,
        metadata: {
          userRole: 'patient',
          timestamp: '2024-01-20T10:35:00Z'
        }
      }
    }
  }
};

/**
 * GET /api/v1/patients/:patientId/health-data
 * Retrieve patient health data (role-restricted)
 */
export const getPatientDataEndpoint = {
  path: '/api/v1/patients/:patientId/health-data',
  method: 'GET',
  auth: 'required',
  description: 'Fetch patient health data with role-based filtering',
  queryParams: {
    includeMedications: 'boolean (optional, default: true)',
    includeReports: 'boolean (optional, default: true)',
    includeAlerts: 'boolean (optional, default: false)',
    limit: 'number (optional, default: 100)'
  },
  responseBody: {
    success: 'boolean',
    data: {
      vitals: 'object',
      medications: 'array',
      reports: 'array',
      alerts: 'array (if authorized)'
    },
    metadata: {
      lastUpdated: 'ISO datetime',
      dataClassification: 'string'
    }
  }
};

/**
 * POST /api/v1/alerts
 * Create alert (typically for emergency situations)
 */
export const createAlertEndpoint = {
  path: '/api/v1/alerts',
  method: 'POST',
  auth: 'required',
  description: 'Create emergency or health alert',
  requestBody: {
    patientId: 'string (required)',
    alertType: 'string (required)',
    severity: 'enum: low|medium|high (required)',
    message: 'string (required)',
    triggeredBy: 'string (user ID, optional)'
  },
  responseBody: {
    success: 'boolean',
    alertId: 'string',
    timestamp: 'ISO datetime'
  }
};

/**
 * GET /api/v1/users/:userId/role
 * Get user role and permissions
 */
export const getUserRoleEndpoint = {
  path: '/api/v1/users/:userId/role',
  method: 'GET',
  auth: 'required',
  description: 'Fetch user role and permissions',
  responseBody: {
    success: 'boolean',
    role: 'string',
    permissions: 'array',
    dataAccess: 'object'
  }
};

/**
 * POST /api/v1/conversation/start
 * Initialize conversation session
 */
export const startConversationEndpoint = {
  path: '/api/v1/conversation/start',
  method: 'POST',
  auth: 'required',
  description: 'Start new conversation session',
  requestBody: {
    userId: 'string (required)',
    userRole: 'string (required)',
    patientId: 'string (optional)'
  },
  responseBody: {
    success: 'boolean',
    conversationId: 'string',
    sessionToken: 'string'
  }
};

/**
 * GET /api/v1/conversation/:conversationId/history
 * Get conversation history
 */
export const getConversationHistoryEndpoint = {
  path: '/api/v1/conversation/:conversationId/history',
  method: 'GET',
  auth: 'required',
  description: 'Fetch conversation history',
  queryParams: {
    limit: 'number (optional, default: 50)',
    offset: 'number (optional, default: 0)'
  },
  responseBody: {
    success: 'boolean',
    messages: 'array of {role, content, timestamp}',
    totalCount: 'number'
  }
};

/**
 * POST /api/v1/health-check
 * System health check (admin only)
 */
export const healthCheckEndpoint = {
  path: '/api/v1/health-check',
  method: 'GET',
  auth: 'admin',
  description: 'Check system health and LLM connectivity',
  responseBody: {
    success: 'boolean',
    status: 'string',
    services: {
      database: 'online|offline',
      llm: 'online|offline',
      auth: 'online|offline'
    },
    timestamp: 'ISO datetime'
  }
};

/**
 * IMPLEMENTATION GUIDE FOR ANTIGRAVITY
 * 
 * 1. In Antigravity Dashboard:
 *    - Go to APIs / Functions
 *    - Create new API endpoints from above definitions
 *    - Link to backend functions (healthcareAIFunction.js, etc.)
 * 
 * 2. Authentication:
 *    - Enable JWT token validation
 *    - Store user roles in token claims
 *    - Validate permissions at endpoint level
 * 
 * 3. Database Integration:
 *    - Connect to schema.sql tables
 *    - Use parameterized queries to prevent SQL injection
 *    - Log all data access for audit trail
 * 
 * 4. Error Handling:
 *    - Return 400 for validation errors
 *    - Return 401 for auth failures
 *    - Return 403 for permission denials
 *    - Return 500 for server errors with error ID
 * 
 * 5. Rate Limiting:
 *    - Implement rate limiting per user (100 req/min)
 *    - Strict limits for emergency endpoints
 * 
 * 6. Monitoring:
 *    - Log all API calls
 *    - Monitor LLM API costs
 *    - Track error rates and types
 */

export default {
  endpoints: {
    chatEndpoint,
    getPatientDataEndpoint,
    createAlertEndpoint,
    getUserRoleEndpoint,
    startConversationEndpoint,
    getConversationHistoryEndpoint,
    healthCheckEndpoint
  }
};
