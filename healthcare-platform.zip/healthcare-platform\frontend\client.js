/**
 * Frontend Integration Library
 * JavaScript/TypeScript client for Healthcare Platform
 */

/**
 * Healthcare AI Client
 * Main class for frontend integration
 */
export class HealthcareAIClient {
  constructor(config = {}) {
    this.baseURL = config.baseURL || 'http://localhost:3000/api/v1';
    this.userId = config.userId;
    this.userRole = config.userRole;
    this.token = config.token;
    this.conversationId = null;
    this.conversationHistory = [];
  }

  /**
   * Set user context
   */
  setUser(userId, userRole, token) {
    this.userId = userId;
    this.userRole = userRole;
    this.token = token;
  }

  /**
   * Send message to healthcare AI
   */
  async sendMessage(message, patientId = null) {
    try {
      const response = await fetch(`${this.baseURL}/chat`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${this.token}`
        },
        body: JSON.stringify({
          userId: this.userId,
          userRole: this.userRole,
          patientId,
          message,
          conversationId: this.conversationId,
          conversationHistory: this.conversationHistory
        })
      });

      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.error || 'Failed to send message');
      }

      const data = await response.json();

      // Update conversation history
      this.conversationHistory.push({
        role: 'user',
        content: message,
        timestamp: new Date().toISOString()
      });

      this.conversationHistory.push({
        role: 'assistant',
        content: data.response,
        timestamp: data.metadata?.timestamp
      });

      return {
        success: true,
        response: data.response,
        isEmergency: data.isEmergency,
        metadata: data.metadata
      };

    } catch (error) {
      console.error('Error sending message:', error);
      return {
        success: false,
        error: error.message
      };
    }
  }

  /**
   * Get patient health data
   */
  async getPatientHealthData(patientId, options = {}) {
    try {
      const params = new URLSearchParams();

      if (options.includeMedications !== undefined) {
        params.append('includeMedications', options.includeMedications);
      }
      if (options.includeReports !== undefined) {
        params.append('includeReports', options.includeReports);
      }
      if (options.includeAlerts !== undefined) {
        params.append('includeAlerts', options.includeAlerts);
      }

      const response = await fetch(
        `${this.baseURL}/patients/${patientId}/health-data?${params}`,
        {
          method: 'GET',
          headers: {
            'Authorization': `Bearer ${this.token}`
          }
        }
      );

      if (!response.ok) {
        throw new Error('Failed to fetch health data');
      }

      return await response.json();

    } catch (error) {
      console.error('Error fetching health data:', error);
      return { success: false, error: error.message };
    }
  }

  /**
   * Start new conversation
   */
  async startConversation(patientId = null) {
    try {
      const response = await fetch(`${this.baseURL}/conversation/start`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${this.token}`
        },
        body: JSON.stringify({
          userId: this.userId,
          userRole: this.userRole,
          patientId
        })
      });

      if (!response.ok) {
        throw new Error('Failed to start conversation');
      }

      const data = await response.json();
      this.conversationId = data.conversationId;
      this.conversationHistory = [];

      return data;

    } catch (error) {
      console.error('Error starting conversation:', error);
      return { success: false, error: error.message };
    }
  }

  /**
   * Get conversation history
   */
  async getConversationHistory(limit = 50, offset = 0) {
    try {
      if (!this.conversationId) {
        throw new Error('No active conversation');
      }

      const params = new URLSearchParams({
        limit,
        offset
      });

      const response = await fetch(
        `${this.baseURL}/conversation/${this.conversationId}/history?${params}`,
        {
          method: 'GET',
          headers: {
            'Authorization': `Bearer ${this.token}`
          }
        }
      );

      if (!response.ok) {
        throw new Error('Failed to fetch history');
      }

      return await response.json();

    } catch (error) {
      console.error('Error fetching conversation history:', error);
      return { success: false, error: error.message };
    }
  }

  /**
   * Get user role and permissions
   */
  async getUserRole(userId = null) {
    try {
      const id = userId || this.userId;

      const response = await fetch(`${this.baseURL}/users/${id}/role`, {
        method: 'GET',
        headers: {
          'Authorization': `Bearer ${this.token}`
        }
      });

      if (!response.ok) {
        throw new Error('Failed to fetch role');
      }

      return await response.json();

    } catch (error) {
      console.error('Error fetching user role:', error);
      return { success: false, error: error.message };
    }
  }

  /**
   * Create alert (admin/doctor only)
   */
  async createAlert(patientId, alertType, severity, message) {
    try {
      const response = await fetch(`${this.baseURL}/alerts`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${this.token}`
        },
        body: JSON.stringify({
          patientId,
          alertType,
          severity,
          message
        })
      });

      if (!response.ok) {
        throw new Error('Failed to create alert');
      }

      return await response.json();

    } catch (error) {
      console.error('Error creating alert:', error);
      return { success: false, error: error.message };
    }
  }
}

export default HealthcareAIClient;
