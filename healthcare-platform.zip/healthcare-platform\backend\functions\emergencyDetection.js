/**
 * Emergency Detection & Response System
 * Handles emergency keyword detection and emergency protocols
 */

/**
 * Comprehensive emergency keywords and phrases
 */
export const EMERGENCY_KEYWORDS = {
  critical: [
    'help',
    'emergency',
    'urgent',
    'crisis',
    'dying',
    '911',
    'call ambulance'
  ],
  physical_danger: [
    'pain',
    'severe pain',
    'chest pain',
    'heart attack',
    'stroke',
    'cannot breathe',
    'unconscious',
    'unresponsive',
    'bleeding',
    'major bleeding',
    'choking',
    'severe burn',
    'poison',
    'overdose',
    'seized',
    'seizure'
  ],
  mental_health_crisis: [
    'suicidal',
    'suicide',
    'harm myself',
    'hurt myself',
    'want to die',
    'hopeless',
    'crisis',
    'panic attack'
  ],
  severe_symptoms: [
    'severe headache',
    'vision loss',
    'speech problems',
    'paralysis',
    'numbness',
    'fainting',
    'loss of consciousness'
  ]
};

/**
 * Emergency severity classification
 */
export const SEVERITY_LEVELS = {
  LOW: 'low',
  MEDIUM: 'medium',
  HIGH: 'high',
  CRITICAL: 'critical'
};

/**
 * Detect emergency from user message
 * @param {string} message - User message
 * @returns {object} Emergency detection result
 */
export function detectEmergency(message) {
  if (!message || typeof message !== 'string') {
    return { isEmergency: false, severity: null, keywords: [] };
  }

  const lowerMessage = message.toLowerCase().trim();
  const detectedKeywords = [];
  let severity = SEVERITY_LEVELS.LOW;

  // Check critical keywords
  for (const keyword of EMERGENCY_KEYWORDS.critical) {
    if (lowerMessage.includes(keyword)) {
      detectedKeywords.push(keyword);
      severity = SEVERITY_LEVELS.CRITICAL;
    }
  }

  // If no critical keywords, check physical danger
  if (detectedKeywords.length === 0) {
    for (const keyword of EMERGENCY_KEYWORDS.physical_danger) {
      if (lowerMessage.includes(keyword)) {
        detectedKeywords.push(keyword);
        severity = SEVERITY_LEVELS.HIGH;
      }
    }
  }

  // Check mental health crisis
  if (detectedKeywords.length === 0) {
    for (const keyword of EMERGENCY_KEYWORDS.mental_health_crisis) {
      if (lowerMessage.includes(keyword)) {
        detectedKeywords.push(keyword);
        severity = SEVERITY_LEVELS.HIGH;
      }
    }
  }

  // Check severe symptoms
  if (detectedKeywords.length === 0) {
    for (const keyword of EMERGENCY_KEYWORDS.severe_symptoms) {
      if (lowerMessage.includes(keyword)) {
        detectedKeywords.push(keyword);
        severity = SEVERITY_LEVELS.MEDIUM;
      }
    }
  }

  return {
    isEmergency: detectedKeywords.length > 0,
    severity: detectedKeywords.length > 0 ? severity : null,
    keywords: detectedKeywords
  };
}

/**
 * Get emergency response based on detected keywords
 * @param {object} detection - Result from detectEmergency()
 * @returns {string} Emergency response text
 */
export function getEmergencyResponse(detection) {
  const { severity, keywords } = detection;

  // Critical emergency
  if (severity === SEVERITY_LEVELS.CRITICAL) {
    return `🚨 CRITICAL EMERGENCY ALERT 🚨

CALL EMERGENCY SERVICES IMMEDIATELY: 911

DO NOT WAIT FOR FURTHER ASSISTANCE.

Critical situation detected: "${keywords[0]}"

Follow basic first-aid guidance only while waiting:
1. Stay calm
2. Ensure safety (move away from danger if possible)
3. Follow dispatcher instructions
4. Keep this line available for emergency services

Your location and emergency have been logged.`;
  }

  // High emergency (physical or mental health)
  if (severity === SEVERITY_LEVELS.HIGH) {
    return `⚠️ EMERGENCY SITUATION DETECTED ⚠️

Detected emergency: "${keywords[0]}"

PLEASE CALL EMERGENCY SERVICES: 911

While waiting for help:
1. Find a safe location
2. Call 911 or emergency services in your area
3. Stay on the line with dispatcher
4. Do not delay seeking professional help
5. Notify people around you if possible

This situation requires immediate professional medical attention.
AI assistance cannot replace emergency response.`;
  }

  // Medium emergency
  if (severity === SEVERITY_LEVELS.MEDIUM) {
    return `⚠️ SERIOUS SITUATION - PROFESSIONAL HELP NEEDED ⚠️

Detected concern: "${keywords[0]}"

STRONGLY RECOMMEND:
- Call 911 if situation worsens immediately
- Contact your doctor or urgent care facility
- Seek immediate professional medical evaluation
- Do not self-treat this condition

This requires professional evaluation and is beyond AI guidance.`;
  }

  return 'If you feel this is an emergency, please call 911.';
}

/**
 * Create emergency alert record
 * @param {object} params - Emergency parameters
 * @returns {Promise<object>} Created alert
 */
export async function createEmergencyAlert(params) {
  const {
    userId,
    userRole,
    patientId,
    message,
    detectedKeywords,
    severity
  } = params;

  try {
    const alertId = generateId();
    const timestamp = new Date().toISOString();

    // Insert into alerts table
    const query = `
      INSERT INTO Alerts (
        alert_id, patient_id, alert_type, severity,
        message, triggered_by, created_at
      ) VALUES ($1, $2, $3, $4, $5, $6, $7)
    `;

    const values = [
      alertId,
      patientId || userId,
      'emergency_detected',
      severity,
      `Emergency Keywords: ${detectedKeywords.join(', ')} | Message: ${message.substring(0, 200)}`,
      userId,
      timestamp
    ];

    // Execute query (in production)
    // await executeQuery(query, values);

    console.warn('[EMERGENCY ALERT CREATED]', {
      alertId,
      patientId: patientId || userId,
      severity,
      keywords: detectedKeywords,
      timestamp
    });

    return {
      alertId,
      timestamp,
      severity,
      status: 'alert_created'
    };

  } catch (error) {
    console.error('Error creating emergency alert:', error);
    throw error;
  }
}

/**
 * Notify emergency contacts
 * @param {object} params - Notification parameters
 * @returns {Promise<void>}
 */
export async function notifyEmergencyContacts(params) {
  const {
    userId,
    patientId,
    severity,
    message
  } = params;

  try {
    // In production, this would:
    // 1. Query emergency contacts from database
    // 2. Send SMS/Email/Push notifications
    // 3. Log notification attempts

    console.warn('[EMERGENCY NOTIFICATION]', {
      patientId: patientId || userId,
      severity,
      timestamp: new Date().toISOString()
    });

    // Placeholder for notification logic
    // await sendSMS(emergencyContact, emergencyMessage);
    // await sendEmail(emergencyContact, emergencyMessage);
    // await sendPushNotification(emergencyContact, emergencyMessage);

  } catch (error) {
    console.error('Error notifying emergency contacts:', error);
  }
}

/**
 * Escalate to human support
 * @param {object} params - Escalation parameters
 * @returns {Promise<void>}
 */
export async function escalateToHumanSupport(params) {
  const {
    userId,
    userRole,
    patientId,
    severity,
    message,
    conversationId
  } = params;

  try {
    // Create escalation ticket
    const ticketId = generateId();
    const timestamp = new Date().toISOString();

    // Insert escalation record
    const query = `
      INSERT INTO EscalationTickets (
        ticket_id, user_id, patient_id, severity,
        original_message, conversation_id, status, created_at
      ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8)
    `;

    console.log('[ESCALATED TO SUPPORT]', {
      ticketId,
      userId,
      patientId,
      severity,
      timestamp
    });

    // In production:
    // - Notify support team
    // - Create help desk ticket
    // - Send to on-call healthcare provider

    return {
      ticketId,
      status: 'escalated',
      estimatedResponseTime: '5-10 minutes'
    };

  } catch (error) {
    console.error('Error escalating to support:', error);
  }
}

/**
 * Log emergency event for audit/compliance
 * @param {object} params - Event parameters
 * @returns {Promise<void>}
 */
export async function logEmergencyEvent(params) {
  const {
    userId,
    patientId,
    severity,
    keywords,
    action,
    timestamp = new Date().toISOString()
  } = params;

  try {
    const query = `
      INSERT INTO EmergencyLog (
        user_id, patient_id, severity, keywords,
        action, timestamp
      ) VALUES ($1, $2, $3, $4, $5, $6)
    `;

    console.log('[EMERGENCY LOG]', {
      userId,
      patientId,
      severity,
      keywords,
      action,
      timestamp
    });

    // For compliance and review
    // INSERT INTO audit log...

  } catch (error) {
    console.error('Error logging emergency event:', error);
  }
}

/**
 * Handle emergency workflow
 * @param {object} params - Complete emergency parameters
 * @returns {Promise<object>} Emergency response data
 */
export async function handleEmergencyWorkflow(params) {
  const {
    userId,
    userRole,
    patientId,
    message,
    detection
  } = params;

  try {
    // 1. Create emergency alert
    await createEmergencyAlert({
      userId,
      userRole,
      patientId,
      message,
      detectedKeywords: detection.keywords,
      severity: detection.severity
    });

    // 2. Notify emergency contacts
    await notifyEmergencyContacts({
      userId,
      patientId,
      severity: detection.severity,
      message
    });

    // 3. Escalate to human support
    const escalation = await escalateToHumanSupport({
      userId,
      userRole,
      patientId,
      severity: detection.severity,
      message,
      conversationId: generateId()
    });

    // 4. Log emergency event
    await logEmergencyEvent({
      userId,
      patientId,
      severity: detection.severity,
      keywords: detection.keywords,
      action: 'emergency_workflow_triggered'
    });

    return {
      success: true,
      emergency: true,
      severity: detection.severity,
      response: getEmergencyResponse(detection),
      escalationTicket: escalation,
      actions: [
        'Alert created',
        'Emergency contacts notified',
        'Human support escalated',
        'Event logged for compliance'
      ]
    };

  } catch (error) {
    console.error('Error in emergency workflow:', error);
    return {
      success: false,
      emergency: true,
      error: 'Emergency workflow error - attempting fallback notification'
    };
  }
}

/**
 * Helper: Generate unique ID
 */
function generateId() {
  return `${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
}

export default {
  detectEmergency,
  getEmergencyResponse,
  createEmergencyAlert,
  notifyEmergencyContacts,
  escalateToHumanSupport,
  logEmergencyEvent,
  handleEmergencyWorkflow,
  EMERGENCY_KEYWORDS,
  SEVERITY_LEVELS
};
