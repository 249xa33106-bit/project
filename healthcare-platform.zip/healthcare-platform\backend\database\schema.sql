-- Smart Healthcare AI Platform Database Schema
-- Antigravity Backend Database Setup

-- ============================================
-- 1. USERS TABLE (Role Management)
-- ============================================
CREATE TABLE Users (
    user_id STRING PRIMARY KEY,
    name STRING NOT NULL,
    email STRING NOT NULL UNIQUE,
    role ENUM('patient', 'doctor', 'caretaker', 'admin') NOT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    is_active BOOLEAN DEFAULT TRUE
);

-- ============================================
-- 2. PATIENT HEALTH DATA TABLE
-- ============================================
CREATE TABLE PatientHealthData (
    patient_id STRING NOT NULL,
    data_id STRING PRIMARY KEY,
    vitals JSON,
    reports JSON,
    medications JSON,
    condition_notes TEXT,
    timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
    created_by STRING NOT NULL,
    FOREIGN KEY (patient_id) REFERENCES Users(user_id),
    FOREIGN KEY (created_by) REFERENCES Users(user_id)
);

-- ============================================
-- 3. ALERTS TABLE (Emergency & Monitoring)
-- ============================================
CREATE TABLE Alerts (
    alert_id STRING PRIMARY KEY,
    patient_id STRING NOT NULL,
    alert_type STRING NOT NULL,
    severity ENUM('low', 'medium', 'high') NOT NULL,
    message TEXT,
    triggered_by STRING,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    resolved BOOLEAN DEFAULT FALSE,
    resolved_at DATETIME,
    FOREIGN KEY (patient_id) REFERENCES Users(user_id),
    FOREIGN KEY (triggered_by) REFERENCES Users(user_id)
);

-- ============================================
-- 4. AI CONVERSATION LOG TABLE
-- ============================================
CREATE TABLE ConversationLog (
    conversation_id STRING PRIMARY KEY,
    user_id STRING NOT NULL,
    patient_id STRING,
    user_role STRING NOT NULL,
    user_message TEXT NOT NULL,
    ai_response TEXT NOT NULL,
    prompt_used STRING,
    is_emergency BOOLEAN DEFAULT FALSE,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES Users(user_id),
    FOREIGN KEY (patient_id) REFERENCES Users(user_id)
);

-- ============================================
-- 5. APPOINTMENT TABLE (Optional)
-- ============================================
CREATE TABLE Appointments (
    appointment_id STRING PRIMARY KEY,
    patient_id STRING NOT NULL,
    doctor_id STRING NOT NULL,
    appointment_date DATETIME NOT NULL,
    status ENUM('scheduled', 'completed', 'cancelled') DEFAULT 'scheduled',
    notes TEXT,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (patient_id) REFERENCES Users(user_id),
    FOREIGN KEY (doctor_id) REFERENCES Users(user_id)
);

-- ============================================
-- INDEXES FOR PERFORMANCE
-- ============================================
CREATE INDEX idx_users_role ON Users(role);
CREATE INDEX idx_health_data_patient ON PatientHealthData(patient_id);
CREATE INDEX idx_health_data_timestamp ON PatientHealthData(timestamp);
CREATE INDEX idx_alerts_patient ON Alerts(patient_id);
CREATE INDEX idx_alerts_severity ON Alerts(severity);
CREATE INDEX idx_alerts_created ON Alerts(created_at);
CREATE INDEX idx_conversation_user ON ConversationLog(user_id);
CREATE INDEX idx_conversation_patient ON ConversationLog(patient_id);
