/**
 * Role-Based Logic & Access Control
 * Manages user permissions, data access, and role-specific behavior
 */

/**
 * Role Definitions & Permissions
 */
export const ROLES = {
  patient: {
    name: 'Patient',
    permissions: [
      'view_own_health_data',
      'ask_health_questions',
      'view_own_appointments',
      'view_own_medications'
    ],
    data_access: {
      own_vitals: true,
      own_reports: true,
      own_medications: true,
      other_patients: false,
      all_alerts: false,
      system_admin: false
    }
  },
  doctor: {
    name: 'Doctor',
    permissions: [
      'view_assigned_patients',
      'view_patient_health_data',
      'create_notes',
      'manage_appointments',
      'coordinate_care'
    ],
    data_access: {
      own_vitals: true,
      own_reports: true,
      own_medications: true,
      assigned_patients: true,
      other_patients: false,
      all_alerts: false,
      system_admin: false
    }
  },
  caretaker: {
    name: 'Caretaker',
    permissions: [
      'view_assigned_patients_summary',
      'receive_alerts',
      'help_medication_reminders',
      'coordinate_with_doctors'
    ],
    data_access: {
      own_vitals: true,
      own_reports: false,
      own_medications: true,
      assigned_patients_summary: true,
      other_patients: false,
      all_alerts: false,
      system_admin: false
    }
  },
  admin: {
    name: 'Administrator',
    permissions: [
      'manage_users',
      'view_system_health',
      'manage_access_control',
      'generate_reports',
      'audit_logs'
    ],
    data_access: {
      own_vitals: true,
      own_reports: true,
      own_medications: true,
      all_patients_aggregated: true,
      system_admin: true
    }
  }
};

/**
 * Check if user has permission
 * @param {string} role - User role
 * @param {string} permission - Permission to check
 * @returns {boolean} True if user has permission
 */
export function hasPermission(role, permission) {
  const roleConfig = ROLES[role];
  if (!roleConfig) return false;
  return roleConfig.permissions.includes(permission);
}

/**
 * Check if user can access patient data
 * @param {string} userId - User ID
 * @param {string} userRole - User role
 * @param {string} patientId - Patient ID to access
 * @param {string} dataType - Type of data (vitals, medications, reports, etc.)
 * @returns {Promise<boolean>} True if authorized
 */
export async function canAccessPatientData(userId, userRole, patientId, dataType) {
  const roleConfig = ROLES[userRole];
  if (!roleConfig) return false;

  // Patients can only access their own data
  if (userRole === 'patient') {
    if (userId !== patientId) return false;
    return roleConfig.data_access[`own_${dataType}`] === true;
  }

  // Doctors/Caretakers can access assigned patients
  if (['doctor', 'caretaker'].includes(userRole)) {
    // Check if user is assigned to this patient
    const isAssigned = await checkPatientAssignment(userId, patientId);
    if (!isAssigned) return false;

    return roleConfig.data_access[`assigned_patients${dataType ? '_' + dataType : ''}`] === true;
  }

  // Admins have broad access for authorized purposes
  if (userRole === 'admin') {
    return roleConfig.data_access.system_admin === true;
  }

  return false;
}

/**
 * Get data access level for role
 * @param {string} role - User role
 * @returns {object} Data access configuration
 */
export function getDataAccessLevel(role) {
  const roleConfig = ROLES[role];
  if (!roleConfig) return {};
  return roleConfig.data_access;
}

/**
 * Get role-specific data fields to return
 * @param {string} role - User role
 * @param {object} fullData - Complete patient data
 * @returns {object} Filtered data based on role
 */
export function filterDataByRole(role, fullData) {
  const access = getDataAccessLevel(role);

  const filtered = {};

  // Vitals
  if (access.own_vitals || access.assigned_patients) {
    filtered.vitals = fullData.vitals;
  }

  // Reports
  if (access.own_reports || access.assigned_patients_summary) {
    filtered.reports = fullData.reports?.slice(-3); // Last 3 reports only for caretakers
  } else if (access.assigned_patients_summary && role === 'caretaker') {
    // Caretakers get summary only
    filtered.reports = fullData.reports?.map(r => ({
      type: r.type,
      date: r.date
    }));
  }

  // Medications
  if (access.own_medications || access.assigned_patients) {
    filtered.medications = fullData.medications;
  }

  // Alerts
  if (access.all_alerts) {
    filtered.alerts = fullData.alerts;
  }

  // Metadata always included
  filtered.metadata = {
    lastUpdated: fullData.timestamp,
    dataClassification: role === 'admin' ? 'full' : 'partial'
  };

  return filtered;
}

/**
 * Check if user is assigned to patient
 * @param {string} userId - User ID
 * @param {string} patientId - Patient ID
 * @returns {Promise<boolean>} True if assigned
 */
async function checkPatientAssignment(userId, patientId) {
  try {
    // Query database for assignment
    const query = `
      SELECT 1 FROM PatientAssignments
      WHERE user_id = $1 AND patient_id = $2
      LIMIT 1
    `;

    // In production, this would query the database
    // For now, return true (assumes assignment exists)
    return true;

  } catch (error) {
    console.error('Error checking patient assignment:', error);
    return false;
  }
}

/**
 * Get LLM behavior restrictions by role
 * @param {string} role - User role
 * @returns {object} LLM behavior rules
 */
export function getLLMBehaviorRules(role) {
  const rules = {
    patient: {
      canViewOwnData: true,
      canViewOthersData: false,
      canMakeDiagnosis: false,
      canRecommendTreatment: false,
      dataVisibility: 'personal',
      alertsSeverity: ['high'] // Only see critical alerts
    },
    doctor: {
      canViewOwnData: true,
      canViewAssignedPatients: true,
      canMakeDiagnosis: false, // Still no AI diagnosis
      canRecommendTreatment: false,
      dataVisibility: 'assigned',
      alertsSeverity: ['low', 'medium', 'high'],
      responsibilityLevel: 'clinical'
    },
    caretaker: {
      canViewOwnData: true,
      canViewAssignedPatients: true,
      canMakeDiagnosis: false,
      canRecommendTreatment: false,
      dataVisibility: 'assigned_summary',
      alertsSeverity: ['high', 'medium'],
      responsibilityLevel: 'support'
    },
    admin: {
      canViewAllData: true,
      canMakeDiagnosis: false,
      canRecommendTreatment: false,
      dataVisibility: 'aggregated',
      alertsSeverity: ['low', 'medium', 'high'],
      responsibilityLevel: 'system'
    }
  };

  return rules[role] || {};
}

/**
 * Log access for audit trail
 * @param {object} accessInfo - Access information
 * @returns {Promise<void>}
 */
export async function logDataAccess(accessInfo) {
  try {
    const {
      userId,
      userRole,
      patientId,
      dataType,
      accessGranted,
      timestamp = new Date().toISOString()
    } = accessInfo;

    // Log to audit table (in production)
    console.log('[AUDIT] Data Access:', {
      userId,
      userRole,
      patientId,
      dataType,
      accessGranted,
      timestamp
    });

    // Save to database for compliance
    // INSERT INTO AuditLog ...

  } catch (error) {
    console.error('Error logging data access:', error);
  }
}

export default {
  ROLES,
  hasPermission,
  canAccessPatientData,
  getDataAccessLevel,
  filterDataByRole,
  getLLMBehaviorRules,
  logDataAccess
};
